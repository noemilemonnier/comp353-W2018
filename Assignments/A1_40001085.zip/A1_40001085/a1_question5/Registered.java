package a1_question5;

public class Registered {
	private int SID;
	private int CID;
	private double Grade;

	public Registered(int SID, int CID, double Grade) {
		this.SID = SID;
		this.CID = CID;
		this.Grade =  Grade;
	}
	public int getSID() {
		return SID;
	}
	public void setSID(int sID) {
		SID = sID;
	}
	public int getCID() {
		return CID;
	}
	public void setCID(int cID) {
		CID = cID;
	}
	public double getGrade() {
		return Grade;
	}
	public void setGrade(double grade) {
		Grade = grade;
	}

	public String toString() {
        return  "SID: " + this.SID + "\nCID: " + this.CID + "\nGrade: " + this.Grade;
    }

}
