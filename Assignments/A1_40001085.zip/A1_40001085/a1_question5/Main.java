package a1_question5;


public class Main {

	public static void main(String[] args){
		// list of courses 
		Course cr1 = new Course(9873,"COMP354",4);
		Course cr2 = new Course(6543,"Databases",4);
		Course cr3 = new Course(7654,"COMP346",4);
		Course cr4 = new Course(6543,"Databases",4);
		Course listCourses[]= new Course[4];
		listCourses[0] = cr1;
		listCourses[1] = cr2;
		listCourses[2] = cr3;
		listCourses[3] = cr4;



		//list of students
		Student listStudents[] = new Student[4];
		Student std1 = new Student(40001085,"James Liam","COMPSCI","12 avenue null San Diego UNITED STATES");
		Student std2 = new Student(12345678,"Petter Griffin","SOEN","00 road street Montreal CANADA");
		Student std3 = new Student(11111111,"Lucie Bells","COMPSCI","33 missing street Toronto CANADA");
		Student std4 = new Student(22222222,"Missie Dingo","SOEN","88 avenue saint Los Angeles UNITED STATES");
		listStudents[0] = std1;
		listStudents[1] = std2;
		listStudents[2] = std3;
		listStudents[3] = std4;



		//list of the registered students
		Registered listRegistered[] = new Registered[4];
		Registered rg1 = new Registered(40001085,9873,4.0);
		Registered rg2 = new Registered(12345678,6543,3.7);
		Registered rg3 = new Registered(11111111,7654,2.7);
		Registered rg4 = new Registered(22222222,6543,3.5);
		listRegistered[0]= rg1;
		listRegistered[1] = rg2;
		listRegistered[2] = rg3;
		listRegistered[3] = rg4;


		int courseID = 0;
		int stdID = 0;
		double grd = 0.0;
		String nm = "";
		System.out.println("Here is the list of the students that took the class Databases:");

		for(int i = 0; i<4; i++){
			if(listCourses[i].getCName().equals("Databases")){
				courseID = listCourses[i].getCID();

			}
		}
		for(int k = 0; k<4; k++){

			if(listRegistered[k].getCID() == courseID){

				stdID = listRegistered[k].getSID();
				grd = listRegistered[k].getGrade();

			}
			for(int j =0; j<4; j++){
				if(listStudents[j].getSID() == stdID){
					nm = listStudents[j].getSName();
					System.out.println("Name: " + nm + " Grade: " + grd);
				}
			}
		}
	}
}

