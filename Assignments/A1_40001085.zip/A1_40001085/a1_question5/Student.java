package a1_question5;

public class Student {
	private int SID;
	private String SName;
	private String Program;
	private String Address;

	public Student(int SID, String SName, String Program,String Address ) {
		this.SID = SID;
		this.SName = SName;
		this.Program = Program;
		this.Address = Address;
	}

	public int getSID() {
		return SID;
	}

	public void setSID(int sID) {
		SID = sID;
	}

	public String getSName() {
		return SName;
	}

	public void setSName(String sName) {
		SName = sName;
	}

	public String getProgram() {
		return Program;
	}

	public void setProgram(String program) {
		Program = program;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}
	
	public String toString() {
        return "SID: " + this.SID + "\nSName: " + this.SName + "\nProgram: " + this.Program + "\nAddress: " + this.Address;
    }
	
}
