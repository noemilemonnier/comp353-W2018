package a1_question5;

public class Course {
	private int CID;
	private String CName;
	private int NoOfCredits;

	public Course(int CID, String CName, int NoOfCredits) {
		this.CID = CID;
		this.CName = CName;
		this.NoOfCredits = NoOfCredits;
	}

	public int getCID() {
		return CID;
	}

	public void setCID(int cID) {
		CID = cID;
	}

	public String getCName() {
		return CName;
	}

	public void setCName(String cName) {
		CName = cName;
	}

	public int getNoOfCredits() {
		return NoOfCredits;
	}

	public void setNoOfCredits(int noOfCredits) {
		NoOfCredits = noOfCredits;
	}
	
	public String toString() {
        return "CID: " + this.CID + "\nCName: " + this.CName + "\nNoOfCredits: " + this.NoOfCredits ;
    }
}
